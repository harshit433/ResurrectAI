from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from unsloth.chat_templates import get_chat_template
from unsloth import FastLanguageModel
from unsloth.chat_templates import get_chat_template
from unsloth import FastLanguageModel
import uvicorn
import torch

app = FastAPI()

# Load the model from Hugging Face
model_name = "ressurectAI/Gandhi6.0"

max_seq_length = 2048 # Maximum number of token allowed in a sequence

# Loading the model for running inference from ressurectAI available at https://huggingface.co/ressurectAI/base
model, tokenizer = FastLanguageModel.from_pretrained(
    model_name= model_name,
    max_seq_length=max_seq_length,
    dtype=None,
)
tokenizer = get_chat_template(
    tokenizer,
    mapping={"role": "from", "content": "value", "user": "Person", "assistant": "Gandhi"},
    chat_template="chatml",
)
FastLanguageModel.for_inference(model)

class PredictionRequest(BaseModel):
    text: str
    max_length: int = 2048

@app.post("/predict")
async def predict(request: PredictionRequest):
    try:
        messages = [
        {"from": "Person", "value": "Gandhi ji, {}".format(input)},
        ]
        inputs = tokenizer.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=False,
            return_tensors="pt",
        ).to("cuda")
        result = model.generate(input_ids=inputs,pad_token_id = tokenizer.pad_token_id , max_new_tokens=1024,use_cache=True)
        response = str(tokenizer.batch_decode(result)[0].split('assistant\n')[1].replace('<|im_end|>','').strip())
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)